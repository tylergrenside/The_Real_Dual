﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;

namespace WindowsFormsApp1
{

    public partial class form1 : Form
    {
        
        Graphics g; //declare a graphics object called g
        Sword sword = new Sword();//create object called Sword
        //declare a list  fireballs from the fireball class
        List<Beam> beams = new List<Beam>();
        List<Fireball> fireballs = new List<Fireball>();
        Cultist cultist = new Cultist();
        Random xspeed = new Random();
        bool left, right, up, down, space;
        int lives;
        string move;
        int eneLives;
        bool fired = false;
        public form1()
        {
            InitializeComponent();
            //Prevents panel from flickering
            typeof(Panel).InvokeMember("DoubleBuffered", BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic, null, panel1, new object[] { true });
            for (int i = 0; i < 7; i++)
            {
                int displacement = 10 + (i * 70);
                fireballs.Add(new Fireball(displacement));
            }
        }
       
        private void CheckLives()
        {
            if (lives == 0)
            {
                
                tmrSword.Enabled = false;
                tmrCultist.Enabled = false;
                MessageBox.Show("You have been beaten by the Cultist " + textBox1.Text + ", Now the world's sound is lost forever.");

            }
        }


        private void XLives()
        {

            if (eneLives == 0)
            {
               
                tmrSword.Enabled = false;
                tmrCultist.Enabled = false;
                MessageBox.Show("Congratulations " + textBox1.Text + "! You have beaten the Cultist and returned the world's sound.");

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("The cultist has stolen the world's sound! Use the Arrows Keys to move and space bar to shoot the cultist. You will not be able to fire another beam until the last beam has been destroyed.");
            textBox1.Focus();
            // pass lives from LblLives Text property to lives variable
            lives = int.Parse(plyLives.Text);
            
        }
       
        private void Form1_Paint_1(object sender, PaintEventArgs e)
        {


        }

        private void tmrSword_Tick(object sender, EventArgs e)
        {
            if (right) // if right arrow key pressed
            {
                move = "right";
                sword.MoveSword(move);
            }
            if (left) // if left arrow key pressed
            {
                move = "left";
                sword.MoveSword(move);
            }

            if (up) // if up arrow key pressed
            {
                move = "up";
                sword.MoveSword(move);
            }
            if (down) // if down arrow key pressed
            {
                move = "down";
                sword.MoveSword(move);
            }


            for (int i = 0; i < 7; i++)
            {
                if ((space) && (fired == false)) // if space key pressed
                {
                    beams.Add(new Beam(sword.swordRec));
                    fired = true;
                }

                if (sword.swordRec.IntersectsWith(fireballs[i].fireballRec))
                {
                    //reset fireball[i] back to right of panel
                    fireballs[i].x = -500; // set  y value of planetRec
                    lives -= 1;// lose a life
                    plyLives.Text = lives.ToString();// display number of lives
                    CheckLives();

                }

                bool cultistDamaged = false;

                foreach (Fireball p in fireballs)
                {

                    foreach (Beam m in beams)
                    {
                        if (p.fireballRec.IntersectsWith(m.beamRec)) // When beam hits Fireball
                        {
                            p.x = -500;// Destroys Beam once it reaches the end of the Panel

                            beams.Remove(m);
                            fired = false;
                            break;
                        }
                        if (cultist.cultistRec.IntersectsWith(m.beamRec)) // When Beam hits cultist
                        {
                            
                            beams.Remove(m);
                            fired = false;
                            if (!cultistDamaged)
                            {
                                eneLives -= 1; //Cultist loses a life
                                cultistDamaged = true;
                            }
                            cltLives.Text = eneLives.ToString();// display number of lives

                            break;
                        }
                    }


                }

              
                XLives();
            }
            panel1.Invalidate();
        }





        private void tmrShoot_Tick(object sender, EventArgs e)
        {
            
            if (eneLives <= 10)
            {
                cultist.moveCultist();


            }
        }
        

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            
            tmrCultist.Enabled = true;
            tmrSword.Enabled = true;
            button1.Enabled = false;
            plyName.Text = (textBox1.Text + "'s Lives");
            lives = int.Parse(plyLives.Text);
            eneLives = int.Parse(cltLives.Text);
        }

        private void textBox1_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar)) //Only Allows Characters
            {
                e.Handled = true;
            }
        }

       

        private void tmrCultist_Tick(object sender, EventArgs e)
        {

        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Left) { left = false; }
            if (e.KeyData == Keys.Right) { right = false; }
            if (e.KeyData == Keys.Up) { up = false; }
            if (e.KeyData == Keys.Down) { down = false; }
            if (e.KeyData == Keys.Space) { space = false; }
        }

     
    
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Left) { left = true; }
            if (e.KeyData == Keys.Right) { right = true; }
            if (e.KeyData == Keys.Up) { up = true; }
            if (e.KeyData == Keys.Down) { down = true; }
            if (e.KeyData == Keys.Space) { space = true; }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

           
            g = e.Graphics;
            sword.drawSword(g);
            cultist.drawCultist(g);

            foreach (Beam m in beams) 
            {
                m.draw(g);
                if (m.x >= 650) // if the beam reaches right side of panel
                {
                    beams.Remove(m);
                    fired = false;
                    break;


                }
            }
            foreach (Fireball p in fireballs)
            {

                //if the Fireball reaches the left side of the form relocate it back to the right
                if (p.x <= 0)
                {
                    p.x = 500;


                }

            }
            for (int i = 0; i < 7; i++)
            {
                // generate a random number from 5 to 20 and put it in rndmspeed

                int rndmspeed = xspeed.Next(5, 20);
                fireballs[i].x += -(rndmspeed);



                //call the firebell's class's drawFirebeall method to draw the images
                fireballs[i].draw(g);
            }


        }
        
    }
}
