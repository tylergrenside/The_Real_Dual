﻿
namespace WindowsFormsApp1
{
    partial class form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tmrSword = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tmrCultist = new System.Windows.Forms.Timer(this.components);
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.plyName = new System.Windows.Forms.Label();
            this.plyLives = new System.Windows.Forms.Label();
            this.cltName = new System.Windows.Forms.Label();
            this.cltLives = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tmrSword
            // 
            this.tmrSword.Tick += new System.EventHandler(this.tmrSword_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1239, 770);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // tmrCultist
            // 
            this.tmrCultist.Interval = 50;
            this.tmrCultist.Tick += new System.EventHandler(this.tmrShoot_Tick);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(1281, 83);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(253, 31);
            this.textBox1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1281, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(253, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Enter Your Name Warrior";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1281, 154);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(253, 45);
            this.button1.TabIndex = 3;
            this.button1.Text = "Begin";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // plyName
            // 
            this.plyName.AutoSize = true;
            this.plyName.Location = new System.Drawing.Point(1303, 477);
            this.plyName.Name = "plyName";
            this.plyName.Size = new System.Drawing.Size(115, 25);
            this.plyName.TabIndex = 4;
            this.plyName.Text = "Your Lives";
            // 
            // plyLives
            // 
            this.plyLives.AutoSize = true;
            this.plyLives.Location = new System.Drawing.Point(1308, 531);
            this.plyLives.Name = "plyLives";
            this.plyLives.Size = new System.Drawing.Size(24, 25);
            this.plyLives.TabIndex = 5;
            this.plyLives.Text = "5";
            // 
            // cltName
            // 
            this.cltName.AutoSize = true;
            this.cltName.Location = new System.Drawing.Point(1308, 621);
            this.cltName.Name = "cltName";
            this.cltName.Size = new System.Drawing.Size(144, 25);
            this.cltName.TabIndex = 6;
            this.cltName.Text = "Cultist\'s Lives";
            // 
            // cltLives
            // 
            this.cltLives.AutoSize = true;
            this.cltLives.Location = new System.Drawing.Point(1313, 690);
            this.cltLives.Name = "cltLives";
            this.cltLives.Size = new System.Drawing.Size(36, 25);
            this.cltLives.TabIndex = 7;
            this.cltLives.Text = "20";
            // 
            // form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1663, 865);
            this.Controls.Add(this.cltLives);
            this.Controls.Add(this.cltName);
            this.Controls.Add(this.plyLives);
            this.Controls.Add(this.plyName);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint_1);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer tmrSword;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Timer tmrCultist;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label plyName;
        private System.Windows.Forms.Label plyLives;
        private System.Windows.Forms.Label cltName;
        private System.Windows.Forms.Label cltLives;
    }
}

